<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 04:28:16
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\evaluation\evaluation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:280415756314079f575-14917940%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '359ce79811b27656b17db07d379ae585803cf08c' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\evaluation\\evaluation.tpl',
      1 => 1465210683,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '280415756314079f575-14917940',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'edit' => 0,
    'CUO' => 0,
    'evaluation' => 0,
    'dateDay' => 0,
    'dateTime' => 0,
    'evalTypes' => 0,
    'type' => 0,
    'ERROR_MESSAGES' => 0,
    'error' => 0,
    'SUCCESS_MESSAGES' => 0,
    'success' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_575631407f7e05_07635849',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575631407f7e05_07635849')) {function content_575631407f7e05_07635849($_smarty_tpl) {?>  <?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 
  <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/evaluation.js"></script>
<div class="container">
<div class="row">
   <input hidden value="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
" id="BASE_URL"/>
   <div class="col-md-12">

     <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
     <h2 class="page-header">Edit Evaluation</h2>
     <?php } else { ?>
      <h2 class="page-header">Create Evaluation</h2>
      <?php }?>
      <form id="evaluationForm" class="well form-horizontal" action="#" method="post">
        <input hidden id="CUO" name="CUO" value="<?php echo $_smarty_tpl->tpl_vars['CUO']->value;?>
" />
         <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
         <!-- check the get -->
         <input hidden id="evaluationID" name="evaluationID" value="<?php echo $_smarty_tpl->tpl_vars['evaluation']->value['evaluationid'];?>
" />
         <input id="Action" name="Action" hidden value="Edit">
         <?php } else { ?>
         <input id="Action" name="Action" hidden value="Create">
         <?php }?>
         <div class="form-group">
            <label class="col-md-3 control-label">Evaluation Date</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                 <input type=date name="evaluationDay" id="evaluationDay" class="form-control"> 
				
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("evaluationDay","<?php echo $_smarty_tpl->tpl_vars['dateDay']->value;?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label class="col-md-3 control-label">Evaluation Time</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input type=time name="evaluationTime" id="evaluationTime" min=9:00 max=17:00 step=900 class="form-control"> <!--15m increments -->
				
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("evaluationTime","<?php echo $_smarty_tpl->tpl_vars['dateTime']->value;?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
       
          <div class="form-group">
            <label class="col-md-3 control-label">Evaluation Weight</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input type=number id="weight" name="weight" min=1 max=100 step=1 class="form-control"> <!--15m increments -->
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("weight","<?php echo $_smarty_tpl->tpl_vars['evaluation']->value['weight'];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
           
             <div class="form-group">
            <label class="col-md-3 control-label">Evaluation Type</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  
                	<select name="evaluationType" id="evaluationType" class="form-control" required>
                 
                     <option value="" disabled selected>Select Evaluation Type</option>
                     <?php  $_smarty_tpl->tpl_vars['type'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['type']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['evalTypes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['type']->key => $_smarty_tpl->tpl_vars['type']->value) {
$_smarty_tpl->tpl_vars['type']->_loop = true;
?>
                     <option value=<?php echo $_smarty_tpl->tpl_vars['type']->value['unnest'];?>
><?php echo $_smarty_tpl->tpl_vars['type']->value['unnest'];?>
</option>
                     <?php } ?> 
                  </select>
                    <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                  fillField("evaluationType","<?php echo $_smarty_tpl->tpl_vars['evaluation']->value['evaluationtype'];?>
")
                  evaluationTypeChangeHandler();
                  disableSelect("evaluationType");
                  </script>
                  <?php }?>
                  
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
       <div id=evalType>
         	   </div>
           <div class="row">
         <span class="glyphicon glyphicon-asterisk"></span> 
             <strong>
         Required Field
      </strong>
      </div>
     <div class="form-group">
            <div class="col-md-4 col-md-offset-4">
              <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                <button id="submitNewEvaluation" type="submit" class="btn btn-primary">Edit Evaluation</button>
              <?php } else { ?>
               <button id="submitNewEvaluation" type="submit" class="btn btn-primary">Create New Evaluation</button>
              <?php }?>
            </div>
         </div>
         
         
         <div id="message_status">
         </div>
         <div id="error_messages">
            <?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
            <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
<a class="close" href="#">X</a></div>
            <?php } ?>
         </div>
         <div id="success_messages">
            <?php  $_smarty_tpl->tpl_vars['success'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['success']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['success']->key => $_smarty_tpl->tpl_vars['success']->value) {
$_smarty_tpl->tpl_vars['success']->_loop = true;
?>
            <div class="success"><?php echo $_smarty_tpl->tpl_vars['success']->value;?>
<a class="close" href="#">X</a></div>
            <?php } ?>
         </div>
      </form>
   </div>
</div>
</div>
 <?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
