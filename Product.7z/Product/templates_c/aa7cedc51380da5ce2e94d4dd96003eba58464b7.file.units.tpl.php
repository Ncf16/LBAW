<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 13:45:40
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\curricularUnit\units.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135415756b3e401ccb8-98418098%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa7cedc51380da5ce2e94d4dd96003eba58464b7' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\curricularUnit\\units.tpl',
      1 => 1465298606,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135415756b3e401ccb8-98418098',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5756b3e4051ef8_07983663',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5756b3e4051ef8_07983663')) {function content_5756b3e4051ef8_07983663($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/listTables.css" rel="stylesheet">

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="page-header">Curricular Units
      </h2>
    </div>
    <div class="col-sm-2">
        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/CurricularUnit/createUnit.php">
          <button class="btn btn-primary" id="createUnit">Create New Unit</button>
        </a>
      </div>
    </div>

  <div class="row">
    <br>
  	<table id="mytable" class="table table-striped">
  		<thead>
  			<th class="col-md-5">Name</th>
  			<th class="col-md-3">Area</th>
  			<th class="col-md-2">Credits</th>
  			<th class="col-md-1">Edit</th>
  			<th class="col-md-1">Delete</th>
  		</thead>
  		<tbody id="units">
  		</tbody>
  	</table>

  	<div class="clearfix"></div>
  	<ul class="pagination pull-right">
  	</ul>
  </div>
</div>

<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/Pagination.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/units.js"></script>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
