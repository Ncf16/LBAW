<?php /* Smarty version Smarty-3.1.15, created on 2016-06-06 05:50:21
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\common\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:26665754f2fd985f92-90822372%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4c7762982946a385c230e1f90feefad57f22b564' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\common\\footer.tpl',
      1 => 1465182326,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '26665754f2fd985f92-90822372',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5754f2fd98a7c8_04865167',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5754f2fd98a7c8_04865167')) {function content_5754f2fd98a7c8_04865167($_smarty_tpl) {?><footer>
  <hr>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="text-center">
          <h2>About Us</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="text-center">
          <p> We are the best academy, join us! We are here since 1920 and are the best at what we have to offer! Explore our page to find out more about the opportunities we offer! </p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class= "col-md-4 col-md-offset-4 text-center">
        <br>
        <a class="btn btn-md btn-default btn-block" href="#">Join Us</a>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <br>
        <p>Copyright &copy; AcademicManagement 2016</p>
      </div>
    </div>
  </div>
</footer>    
</body>
</html><?php }} ?>
