<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 04:28:19
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\evaluation\groupWork.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4494575631437e92a6-27987249%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a410fd1cacf652376d6c8b548df545d1dabd4ec8' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\evaluation\\groupWork.tpl',
      1 => 1465249771,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4494575631437e92a6-27987249',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'edit' => 0,
    'groupWork' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57563143814715_62085696',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57563143814715_62085696')) {function content_57563143814715_62085696($_smarty_tpl) {?>     <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
     <h4 class="page-header">Edit Group Work</h4>
     <?php } else { ?>
      <h4 class="page-header">Create Group Work</h4>
      <?php }?>
          <div class="form-group">
            <label class="col-md-3 control-label">Minimum Elements</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input type=number id="minElements" name="minElements" min=2 step=1 class="form-control"> <!--15m increments -->
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("minElements","<?php echo $_smarty_tpl->tpl_vars['groupWork']->value['minelements'];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
               <div class="form-group">
            <label class="col-md-3 control-label">Maximum Elements</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input type=number id="maxElements" name="maxElements" min=2 step=1 class="form-control"> <!--15m increments -->
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("maxElements","<?php echo $_smarty_tpl->tpl_vars['groupWork']->value['maxelements'];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
<?php }} ?>
