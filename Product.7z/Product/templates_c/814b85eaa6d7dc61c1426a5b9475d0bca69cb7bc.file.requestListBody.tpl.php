<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 04:44:30
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\request\requestListBody.tpl" */ ?>
<?php /*%%SmartyHeaderCode:228065756350ee716f4-70007051%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '814b85eaa6d7dc61c1426a5b9475d0bca69cb7bc' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\request\\requestListBody.tpl',
      1 => 1465210683,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '228065756350ee716f4-70007051',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'requests' => 0,
    'request' => 0,
    'BASE_URL' => 0,
    'config' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5756350eecc823_95198516',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5756350eecc823_95198516')) {function content_5756350eecc823_95198516($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\lib\\smarty\\plugins\\modifier.date_format.php';
?><?php  $_smarty_tpl->tpl_vars[htmlspecialchars('request', ENT_QUOTES, 'UTF-8', true)] = new Smarty_Variable; $_smarty_tpl->tpl_vars[htmlspecialchars('request', ENT_QUOTES, 'UTF-8', true)]->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['requests']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars[htmlspecialchars('request', ENT_QUOTES, 'UTF-8', true)]->key => $_smarty_tpl->tpl_vars[htmlspecialchars('request', ENT_QUOTES, 'UTF-8', true)]->value) {
$_smarty_tpl->tpl_vars[htmlspecialchars('request', ENT_QUOTES, 'UTF-8', true)]->_loop = true;
?>
    <tr>
        <th scope="row">
            <a class="btn center-block requestItem">
                <span class="hidden">
                    <?php echo htmlspecialchars(json_encode($_smarty_tpl->tpl_vars['request']->value), ENT_QUOTES, 'UTF-8', true);?>

                </span>
                <?php echo $_smarty_tpl->tpl_vars['request']->value['requestid'];?>

            </a>
        </th>
        <td class="hue">
            <a href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/Person/personalPage.php?person=<?php echo $_smarty_tpl->tpl_vars['request']->value['studentusername'];?>
'><?php echo $_smarty_tpl->tpl_vars['request']->value['studentname'];?>
</a>
        </td>
        <td>
            <?php if ($_smarty_tpl->tpl_vars['request']->value['adminusername']==null) {?>
                None
            <?php } else { ?>
                <a href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/Person/personalPage.php?person=<?php echo $_smarty_tpl->tpl_vars['request']->value['adminusername'];?>
'><?php echo $_smarty_tpl->tpl_vars['request']->value['adminname'];?>
</a>
            <?php }?>

        </td>
        <td>

            <?php if ($_smarty_tpl->tpl_vars['request']->value['approved']==null) {?>
                <?php if ($_smarty_tpl->tpl_vars['request']->value['closed']=='false') {?>
                    <span class="unanswered">Not Answered</span>
                <?php } elseif ($_smarty_tpl->tpl_vars['request']->value['closed']=='true') {?>
                    <span class="canceled">Canceled</span>
                <?php }?>
            <?php } elseif ($_smarty_tpl->tpl_vars['request']->value['approved']=='true') {?>
                <span class="approved">Approved</span>
            <?php } elseif ($_smarty_tpl->tpl_vars['request']->value['approved']=='false') {?>
                <span class="rejected">Rejected</span>
            <?php } else { ?> <?php echo $_smarty_tpl->tpl_vars['request']->value['approved'];?>

            <?php }?>
        </td>

        <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['request']->value['submitiondate'],$_smarty_tpl->tpl_vars['config']->value['requestDate']);?>
</td>

    </tr>
<?php } ?><?php }} ?>
