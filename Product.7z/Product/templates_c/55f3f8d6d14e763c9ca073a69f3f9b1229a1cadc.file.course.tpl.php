<?php /* Smarty version Smarty-3.1.15, created on 2016-06-06 22:57:06
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\course\course.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6645754f5f1712362-05761474%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '55f3f8d6d14e763c9ca073a69f3f9b1229a1cadc' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\course\\course.tpl',
      1 => 1465210683,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6645754f5f1712362-05761474',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5754f5f17742c3_40751758',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'edit' => 0,
    'infoToEdit' => 0,
    'teachers' => 0,
    'teacher' => 0,
    'ERROR_MESSAGES' => 0,
    'error' => 0,
    'SUCCESS_MESSAGES' => 0,
    'success' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5754f5f17742c3_40751758')) {function content_5754f5f17742c3_40751758($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/courseFormValidation.js"></script>
<div class="container">
<div class="row">
   <div class="col-md-12">
     <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
     <h2 class="page-header">Edit Course</h2>
     <?php } else { ?>
      <h2 class="page-header">Create Course</h2>
      <?php }?>
      <form id="courseForm" class="well form-horizontal" action="#" method="post">
         <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
         <input hidden id="courseID" name="courseID" value="<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value['code'];?>
" />
         <input id="Action" name="Action" hidden value="Edit">
         <?php } else { ?>
         <input id="Action" name="Action" hidden value="Create">
         <?php }?>
         <div class="form-group">
            <label class="col-md-3 control-label">Name</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input name="course_name" id="course_name" placeholder="Course Name" class="form-control" type="text" required>
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_name","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["name"];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label class="col-md-3 control-label">Abbreviation</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input name="course_abbreviation" maxlength="5" id="course_abbreviation" placeholder="Abbreviation" class="form-control" type="text" required>
                  <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_abbreviation","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["abbreviation"];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
          
         <div class="form-group">
            <label class="col-md-3 control-label">Director</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                  <select name="course_director" id="course_director" class="form-control" required>
                     <option value="" disabled selected>Select Course Director</option>
                     <?php  $_smarty_tpl->tpl_vars['teacher'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['teacher']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['teachers']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['teacher']->key => $_smarty_tpl->tpl_vars['teacher']->value) {
$_smarty_tpl->tpl_vars['teacher']->_loop = true;
?>
                     <option value=<?php echo $_smarty_tpl->tpl_vars['teacher']->value['academiccode'];?>
><?php echo $_smarty_tpl->tpl_vars['teacher']->value['name'];?>
:<?php echo $_smarty_tpl->tpl_vars['teacher']->value['username'];?>
</option>
                     <?php } ?> 
                  </select>
                  <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_director","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["teachercode"];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label class="col-md-3 control-label">Creation Date</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  <input type="date" name="course_fundate" id="course_fundate" class="form-control"  required>
                  <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_fundate","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["creationdate"];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label class="col-md-3 control-label">Duration</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                  <input name="course_duration" id="course_duration" placeholder="0" class="form-control" type="number" min="1" max="6" readonly>
                  <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_duration","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["courseYears"];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label class="col-md-3 control-label">Degree</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span>
                  <select name="course_degree" id="course_degree" class="form-control" required>
                     <option value="" disabled selected>Select Academic Degree</option>
                     <option>Bachelor</option>
                     <option>Masters</option>
                     <option>PhD</option>
                  </select> 
                  <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_degree","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["coursetype"];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label class="col-md-3 control-label">Description</label>  
               <div class="col-md-8">
                  <textarea class="form-control"  name="course_description" id="course_description" cols="50" ></textarea>
                  <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("course_description","<?php echo $_smarty_tpl->tpl_vars['infoToEdit']->value["description"];?>
");
                  </script>
                  <?php }?>
            </div>
             <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
         </div>
           <div class="row">
         <span class="glyphicon glyphicon-asterisk"></span> 
             <strong>
         Required Field
      </strong>
      </div>
         <div class="form-group">
            <div class="col-md-4 col-md-offset-4">
              <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                <button id="submitNewCourse" type="submit" class="btn btn-primary">Edit Course</button>
              <?php } else { ?>
               <button id="submitNewCourse" type="submit" class="btn btn-primary">Create New Course</button>
              <?php }?>
            </div>
         </div>
         
         <div id="message_status">
         </div>
         <div id="error_messages">
            <?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
            <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
<a class="close" href="#">X</a></div>
            <?php } ?>
         </div>
         <div id="success_messages">
            <?php  $_smarty_tpl->tpl_vars['success'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['success']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['success']->key => $_smarty_tpl->tpl_vars['success']->value) {
$_smarty_tpl->tpl_vars['success']->_loop = true;
?>
            <div class="success"><?php echo $_smarty_tpl->tpl_vars['success']->value;?>
<a class="close" href="#">X</a></div>
            <?php } ?>
         </div>
      </form>
   </div>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
