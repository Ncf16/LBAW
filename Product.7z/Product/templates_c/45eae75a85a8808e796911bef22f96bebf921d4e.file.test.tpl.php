<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 04:28:20
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\evaluation\test.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2807957563144d74d61-04708617%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '45eae75a85a8808e796911bef22f96bebf921d4e' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\evaluation\\test.tpl',
      1 => 1465210683,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2807957563144d74d61-04708617',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'edit' => 0,
    'test' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57563144d9f2e6_06430449',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57563144d9f2e6_06430449')) {function content_57563144d9f2e6_06430449($_smarty_tpl) {?>     <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
     <h4 class="page-header">Edit Test</h4>
     <?php } else { ?>
      <h4 class="page-header">Create Test</h4>
      <?php }?>
          <div class="form-group">
            <label class="col-md-3 control-label">Test Exam Duration</label>  
            <div class="col-md-8 inputGroupContainer">
               <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                  <input type=number id="duration" name="duration"  min=1 step=1 class="form-control"> <!--15m increments -->
                   <?php if ($_smarty_tpl->tpl_vars['edit']->value==true) {?>
                  <script >
                    fillField("duration","<?php echo $_smarty_tpl->tpl_vars['test']->value['duration'];?>
");
                  </script>
                  <?php }?>
                   <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
               </div>
            </div>
         </div>
<?php }} ?>
