<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 06:58:29
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\request\viewModalRequest.tpl" */ ?>
<?php /*%%SmartyHeaderCode:315115756547573b239-45196314%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '259217f31e6acf92be68af5d673fafe7c1aaa49e' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\request\\viewModalRequest.tpl',
      1 => 1465249815,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '315115756547573b239-45196314',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'request' => 0,
    'USERID' => 0,
    'BASE_URL' => 0,
    'config' => 0,
    'ACCOUNT_TYPE' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57565475799143_30262578',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57565475799143_30262578')) {function content_57565475799143_30262578($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\lib\\smarty\\plugins\\modifier.date_format.php';
?><!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"></button>
                <h4 class="modal-title"><strong>Request Nr. <?php echo $_smarty_tpl->tpl_vars['request']->value['requestid'];?>
</strong></h4>
                <input type="hidden" name="requestID" value="<?php echo $_smarty_tpl->tpl_vars['request']->value['requestid'];?>
">
                <input type="hidden" name="userID" value="<?php echo $_smarty_tpl->tpl_vars['USERID']->value;?>
">
            </div>

            <div class="modal-body">
                <p class="pull-right"><strong>Status</strong>:
                    <?php if ($_smarty_tpl->tpl_vars['request']->value['approved']==null) {?>
                        <?php if ($_smarty_tpl->tpl_vars['request']->value['closed']=='false') {?>
                            <span class="unanswered">Not Answered</span>
                        <?php } elseif ($_smarty_tpl->tpl_vars['request']->value['closed']=='true') {?>
                            <span class="canceled">Canceled</span>
                        <?php }?>
                    <?php } elseif ($_smarty_tpl->tpl_vars['request']->value['approved']=='true') {?>
                        <span class="approved">Approved</span>
                    <?php } elseif ($_smarty_tpl->tpl_vars['request']->value['approved']=='false') {?>
                        <span class="rejected">Rejected</span>
                    <?php } else { ?> <?php echo $_smarty_tpl->tpl_vars['request']->value['approved'];?>

                    <?php }?>
                </p>
                <p><strong>Submitted by:</strong>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/Person/personalPage.php?person=<?php echo $_smarty_tpl->tpl_vars['request']->value['studentusername'];?>
"><?php echo $_smarty_tpl->tpl_vars['request']->value['studentname'];?>

                        - <?php echo $_smarty_tpl->tpl_vars['request']->value['studentusername'];?>
</a>
                </p>
                <p class="pull-right"> <strong>Last Update: </strong><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['request']->value['submitiondate'],$_smarty_tpl->tpl_vars['config']->value['requestDate']);?>
</p>
                <p><strong>Answered by: </strong>
                    <?php if ($_smarty_tpl->tpl_vars['request']->value['adminusername']==null) {?>
                        None
                    <?php } else { ?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/Person/personalPage.php?person=<?php echo $_smarty_tpl->tpl_vars['request']->value['adminusername'];?>
"><?php echo $_smarty_tpl->tpl_vars['request']->value['adminname'];?>

                            - <?php echo $_smarty_tpl->tpl_vars['request']->value['adminusername'];?>
</a>
                    <?php }?>
                </p>
                <p><strong>Title: </strong> <?php echo $_smarty_tpl->tpl_vars['request']->value['title'];?>
</p>
                <p><strong>Description: </strong><?php echo $_smarty_tpl->tpl_vars['request']->value['description'];?>
</p>
            </div>

            <div class="modal-footer">
                <?php if ($_smarty_tpl->tpl_vars['ACCOUNT_TYPE']->value=='Admin'&&$_smarty_tpl->tpl_vars['request']->value['closed']=='false') {?>
                    <button id="approve_btn" type="button" class="btn btn-success" data-dismiss="modal">Approve <span class="glyphicon glyphicon-ok"></span></button>
                    <button id="reject_btn" type="button" class="btn btn-danger" data-dismiss="modal">Reject <span class="glyphicon glyphicon-remove"></span></button>
                <?php } elseif ($_smarty_tpl->tpl_vars['ACCOUNT_TYPE']->value=='Student'&&$_smarty_tpl->tpl_vars['request']->value['closed']=='false') {?>
                    <button id="cancel_btn" type="button" class="btn btn-warning" data-dismiss="modal">Cancel Request</button>
                <?php }?>
                <button type="button" class=" btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div><?php }} ?>
