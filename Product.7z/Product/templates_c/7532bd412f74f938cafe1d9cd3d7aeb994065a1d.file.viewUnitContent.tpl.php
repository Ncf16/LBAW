<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 06:57:46
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\CurricularUnit\viewUnitContent.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3172457560d30a3abb5-66010163%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7532bd412f74f938cafe1d9cd3d7aeb994065a1d' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\CurricularUnit\\viewUnitContent.tpl',
      1 => 1465275331,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3172457560d30a3abb5-66010163',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57560d30a7ace6_31624249',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'classes' => 0,
    'hasPermission' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57560d30a7ace6_31624249')) {function content_57560d30a7ace6_31624249($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/content.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/jquery.fileupload.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/jquery.fileupload-ui.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/jquery.fileupload-noscript.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/jquery.fileupload-ui-noscript.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/style.css" rel="stylesheet">


<div class="container" id="classesPage">
   <div class="row">
      <div class="col-md-12">
         <h2 class="page-header">
            Unit Contents
            <?php if ($_smarty_tpl->tpl_vars['classes']->value['unitInformation']) {?>
            <small><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/CurricularUnit/viewUnitOccurrence.php?uc=<?php echo $_smarty_tpl->tpl_vars['classes']->value['unit'];?>
" > <?php echo $_smarty_tpl->tpl_vars['classes']->value['unitInformation'];?>
</a></small>
            <?php } elseif ($_smarty_tpl->tpl_vars['classes']->value['teacherInformation']) {?>
            <small><?php echo $_smarty_tpl->tpl_vars['classes']->value['teacherInformation'];?>
</small>
            <?php }?>
         </h2>
      </div>
       <?php if ($_smarty_tpl->tpl_vars['hasPermission']->value) {?>
      <div class="col-sm-2">

          <div>

              <button id="modal_upload_btn" class="btn" type="button" value="Upload">Upload</button>

          </div>
      </div>
       <?php }?>
    </div>

  <div class="row">
      <br>
      <table id="mytable" class="table bordered table-striped">
         <thead>

            <th class="col-md-3">File</th>
            <?php if ($_smarty_tpl->tpl_vars['hasPermission']->value) {?>
            <th class="col-md-1 col-md-offset-1">Delete</th>
            <?php }?>
         </thead>
         <tbody class="contentsListBody">
         </tbody>
      </table>

      <div class="clearfix"></div>
      <ul class="pagination pull-right">
      </ul>
   </div>
</div>



<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/jquery.iframe-transport.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/vendor/jquery.ui.widget.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/jquery.fileupload.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/jquery.fileupload-ui.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/pagination.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/curricularContentList.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/curricularContentManager.js"></script>



<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



<!-- Modal -->

<div id="fileUploadModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"></button>
                <h4 class="modal-title"><strong>Curricular Unit File Upload</strong></h4>
            </div>

            <div class="modal-body">
                <form id="uploadFileForm" class="form-horizontal" action="#" method="post">

                    <!-- Upload button -->
                    <div class="form-group">
                        <label class="col-md-3 control-label">Upload Here</label>
                        <div class="col-md-8 inputGroupContainer">
                            <div class="input-group">
                                <button id="pretendBtn" type="button" class="btn btn-file">Browse</button>
                                <span id="filedescriptor"></span>
                                <input id="fileupload" class="hidden" type="file" name="file" data-url="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
api/contentUpload.php">
                            </div>
                        </div>
                    </div>

                    <!-- Name -->
                    <div class="form-group">
                        <label class="col-md-3 control-label">Name</label>
                        <div class="col-md-8 inputGroupContainer">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                <input id="filepresentationname" name="fileName"
                                          placeholder="Name the file will have when displayed on the page."
                                          class="form-control" required>

                            </div>
                        </div>
                    </div>

                    <div id="progress">
                        <div class="bar" style="width: 0%;"></div>
                    </div>

                    <div class="form-group">

                        <!-- SUCCESS MESSAGE -->
                        <div id="creation_success" class="text-center">
                        </div>
                        <!-- FAILURE MESSAGE -->
                        <div id="creation_failure" class="text-center">
                        </div>

                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <span id="submitButtonPlace">

                </span>
                <button id="closeBtn" type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
            </div>
        </div>

    </div>
</div>
<?php }} ?>
