<?php /* Smarty version Smarty-3.1.15, created on 2016-06-06 23:12:04
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\person\personList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:272445755e7248f3820-75622019%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '107abcf94b6d495e12563ab320127e2645c7daf8' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\person\\personList.tpl',
      1 => 1465182326,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '272445755e7248f3820-75622019',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5755e7248f7a71_53459686',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5755e7248f7a71_53459686')) {function content_5755e7248f7a71_53459686($_smarty_tpl) {?><table class="table table-striped" >
  <thead>
    <tr class="head">
      <th>Name</th>
      <th>Account Type</th>
    </tr>
  </thead>
  <tbody class="courseListBody" id="person_list">
  </tbody>
</table><?php }} ?>
