<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 04:27:30
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\classes\classes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:599757563112efa843-55469479%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ad4957e48d71771226eb989094cd568082339883' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\classes\\classes.tpl',
      1 => 1465249783,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '599757563112efa843-55469479',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'classes' => 0,
    'accountType' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57563113001116_99504211',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57563113001116_99504211')) {function content_57563113001116_99504211($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/listTables.css" rel="stylesheet">

<div class="container" id="classesPage">
   <div class="row">
      <div class="col-md-12">
         <h2 class="page-header">
            Classes
            <?php if ($_smarty_tpl->tpl_vars['classes']->value['unitInformation']) {?>
            <small><?php echo $_smarty_tpl->tpl_vars['classes']->value['unitInformation'];?>
</small>
            <?php } elseif ($_smarty_tpl->tpl_vars['classes']->value['teacherInformation']) {?>
            <small><?php echo $_smarty_tpl->tpl_vars['classes']->value['teacherInformation'];?>
</small>
            <?php }?>
         </h2>
      </div>
      <?php if ($_smarty_tpl->tpl_vars['accountType']->value!='Student') {?>
      <div class="col-sm-2">
        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/Class/createClass.php<?php if ($_smarty_tpl->tpl_vars['classes']->value['unit']) {?>?unit=<?php echo $_smarty_tpl->tpl_vars['classes']->value['unit'];?>
<?php }?>">
          <button class="btn btn-primary" id="createClass">Create New Class</button>
        </a>
      </div>
       <?php }?>
    </div>

  <div class="row">
      <br>
      <table id="mytable" class="table table-striped">
         <thead>
            <th class="col-md-1">View</th>
            <?php if ($_smarty_tpl->tpl_vars['classes']->value['unitInformation']) {?>
            <th class="col-md-3">Date</th>
            <th <?php if ($_smarty_tpl->tpl_vars['accountType']->value=='Student') {?>
              class="col-md-6"
              <?php } else { ?>
              class="col-md-5"
              <?php }?>
              >Teacher</th>
            <?php } elseif ($_smarty_tpl->tpl_vars['classes']->value['teacherInformation']) {?>
            <th class="col-md-3">Date</th>
            <th class="col-md-5">Unit</th>
            <?php } else { ?>
            <th class="col-md-2">Date</th>
            <th class="col-md-3">Teacher</th>
            <th class="col-md-3">Unit</th>
            <?php }?>
            <th class="col-md-2">Room</th>
            <?php if ($_smarty_tpl->tpl_vars['accountType']->value!='Student') {?>
            <th class="col-md-1">Delete</th>
            <?php }?>
         </thead>
         <tbody id="classes">
         </tbody>
      </table>

      <div class="clearfix"></div>
      <ul class="pagination pull-right">
      </ul>
   </div>
</div>

<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/pagination.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/classes.js"></script>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
