<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 06:58:17
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\request\requestListStudent.tpl" */ ?>
<?php /*%%SmartyHeaderCode:137715756546979dac9-47118283%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a011374316a188ac8e1768ae20ca5f801a015544' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\request\\requestListStudent.tpl',
      1 => 1465210683,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '137715756546979dac9-47118283',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_575654697d2180_89666746',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575654697d2180_89666746')) {function content_575654697d2180_89666746($_smarty_tpl) {?><p>
<hr>
<ul class="nav nav-pills navPills">
    <li id="openRequests" class="active"><a href="#open" data-toggle="tab">Open Requests</a></li>
    <li id="closedRequests"><a href="#closed" data-toggle="tab">Closed Requests</a></li>

    <a id="createRequestBtn" class="pull-right btn" data-toggle="modal" data-target="#requestCreationModal"> Create Request</a>
</ul>


<div class="tab-content">
    <div class="row tab-pane fade in active" id="open">
        <div class="col-lg-12 ">
            <h2>Open Requests</h2>

            <!-- TABLE -->
            <table class="table table-striped">
                <thead>
                <tr class="head">
                    <th>Request ID</th>
                    <th>Submitted by</th>
                    <th>Answered by</th>
                    <th>Status</th>
                    <th>Last Update</th>
                </tr>
                </thead>
                <tbody class="requestListBody" id="request_list">

                </tbody>
            </table>
            <!-- END TABLE -->

            <div class="clearfix"></div>
            <ul class="pagination pull-right">

            </ul>

        </div>
    </div>



    <div class="row tab-pane fade" id="closed">
        <div class="col-lg-12">
            <h2>Closed Requests</h2>

            <!-- TABLE -->
            <table class="table table-striped">
                <thead>
                <tr class="head">
                    <th>Request ID</th>
                    <th>Submitted by</th>
                    <th>Answered by</th>
                    <th>Status</th>
                    <th>Last Update</th>
                </tr>
                </thead>
                <tbody class="requestListBody" id="request_list">

                </tbody>
            </table>
            <!-- END TABLE -->

            <div class="clearfix"></div>
            <ul class="pagination pull-right">

            </ul>

        </div>
    </div>


</div>

</p>
<?php }} ?>
