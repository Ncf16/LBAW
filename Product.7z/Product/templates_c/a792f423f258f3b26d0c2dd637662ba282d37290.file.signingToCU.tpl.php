<?php /* Smarty version Smarty-3.1.15, created on 2016-06-08 13:39:07
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\student\signingToCU.tpl" */ ?>
<?php /*%%SmartyHeaderCode:111965755724ec06f47-17131919%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a792f423f258f3b26d0c2dd637662ba282d37290' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\student\\signingToCU.tpl',
      1 => 1465385900,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '111965755724ec06f47-17131919',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5755724ec46cc4_26172728',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'student' => 0,
    'course' => 0,
    'canSignUpTo' => 0,
    'year' => 0,
    'myId' => 0,
    'cu' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5755724ec46cc4_26172728')) {function content_5755724ec46cc4_26172728($_smarty_tpl) {?> <?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

  <link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/personEdit.css" rel="stylesheet">
<div class="container">
   <div class="row">
      <div class="col-md-12">
         <h2 class="page-header"><?php echo $_smarty_tpl->tpl_vars['student']->value['name'];?>
 Curricular Units To Sign Up </h2>
         <input hidden id="url" name="url" value="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
">
         <form id="signUpForm" class="well form-horizontal" action="#" method="post">
            <input hidden id="pc" name="pCode" value="<?php echo $_smarty_tpl->tpl_vars['student']->value['username'];?>
"/>
            <input hidden  id="cc" name="cCode"  value="<?php echo $_smarty_tpl->tpl_vars['course']->value['code'];?>
"/>
            <?php  $_smarty_tpl->tpl_vars['year'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['year']->_loop = false;
 $_smarty_tpl->tpl_vars['myId'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['canSignUpTo']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['year']->key => $_smarty_tpl->tpl_vars['year']->value) {
$_smarty_tpl->tpl_vars['year']->_loop = true;
 $_smarty_tpl->tpl_vars['myId']->value = $_smarty_tpl->tpl_vars['year']->key;
?>
            <?php if (count($_smarty_tpl->tpl_vars['year']->value)>0) {?>
            <div class="panel panel-default">
               <div class="panel-heading">
                  <h4 class="panel-title">
                     <a data-toggle="collapse" data-parent="#accordion" href="#year<?php echo $_smarty_tpl->tpl_vars['myId']->value;?>
"> <b>Year <?php echo $_smarty_tpl->tpl_vars['myId']->value;?>
</b> </a>
                  </h4>
               </div>
               <div id="year<?php echo $_smarty_tpl->tpl_vars['myId']->value;?>
" class="panel-collapse collapse">
                  <div class="panel-body">
                     <div class="panel-group" id="accordion<?php echo $_smarty_tpl->tpl_vars['myId']->value;?>
">
                        <div class="row">
                           <?php  $_smarty_tpl->tpl_vars['cu'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cu']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['year']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cu']->key => $_smarty_tpl->tpl_vars['cu']->value) {
$_smarty_tpl->tpl_vars['cu']->_loop = true;
?>
                           <div class="form-group">
                              <label class="col-md-3 control-label"><?php echo $_smarty_tpl->tpl_vars['cu']->value['name'];?>
</label>  
                              <div class="col-md-8 inputGroupContainer">
                                 <div class="input-group">
                                    <input type="checkbox"  name="CU_<?php echo $_smarty_tpl->tpl_vars['cu']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['cu']->value['cuoccurrenceid'];?>
"/>
                                 </div>
                              </div>
                           </div>
                           <?php } ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <?php }?>
            <?php } ?>
            <div class="form-group">
               <div class="col-md-4 col-md-offset-4">
                  <button id="signUpFormSubmit" type="submit" class="btn btn-primary">Sign Up</button>
               </div>
            </div>
           <div id="error_messages">
          </div>
         </form>
      </div>
   </div>
</div>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/signUp.js"></script>
 <?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
