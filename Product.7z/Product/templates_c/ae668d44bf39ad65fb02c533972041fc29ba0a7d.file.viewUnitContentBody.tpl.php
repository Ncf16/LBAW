<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 06:57:46
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\curricularUnit\viewUnitContentBody.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21398575653866d34d8-51402430%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ae668d44bf39ad65fb02c533972041fc29ba0a7d' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\curricularUnit\\viewUnitContentBody.tpl',
      1 => 1465275463,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21398575653866d34d8-51402430',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57565386713540_94093246',
  'variables' => 
  array (
    'contents' => 0,
    'content' => 0,
    'ACCOUNT_TYPE' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57565386713540_94093246')) {function content_57565386713540_94093246($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['content'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['content']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['contents']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['content']->key => $_smarty_tpl->tpl_vars['content']->value) {
$_smarty_tpl->tpl_vars['content']->_loop = true;
?>
<tr>
    <th scope="row">
        <a class="center-block requestItem">
            <a href="<?php echo $_smarty_tpl->tpl_vars['content']->value['filepath'];?>
" target="_blank">Download:  <?php echo $_smarty_tpl->tpl_vars['content']->value['filepresentationname'];?>
</a>
            <span class="hidden"><?php echo $_smarty_tpl->tpl_vars['content']->value['filepath'];?>
</span>
        </a>

    </th>
    <?php if ($_smarty_tpl->tpl_vars['ACCOUNT_TYPE']->value!='Student') {?>
    <td class="hue">
        <p>
            <a href="#" class="btn btn-danger btn-xs deleteContentBtn">
                <span class="glyphicon glyphicon-trash">
                <input type="hidden"  name="uploadid" value="<?php echo $_smarty_tpl->tpl_vars['content']->value['uploadid'];?>
">
            </span>
            </a>


        </p>
    </td>
    <?php }?>
</tr>
<?php } ?><?php }} ?>
