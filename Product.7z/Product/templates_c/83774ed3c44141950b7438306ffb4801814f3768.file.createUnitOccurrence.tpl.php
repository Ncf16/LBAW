<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 04:26:50
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\curricularUnit\createUnitOccurrence.tpl" */ ?>
<?php /*%%SmartyHeaderCode:27352575630ea950001-01542247%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '83774ed3c44141950b7438306ffb4801814f3768' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\curricularUnit\\createUnitOccurrence.tpl',
      1 => 1465182326,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27352575630ea950001-01542247',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_575630ea972981_83921073',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575630ea972981_83921073')) {function content_575630ea972981_83921073($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class="modal-body">
<div class="container">
  <div class="row">
  	<div class="col-lg-12">
  		<h2 class="page-header">Create Curricular Unit Occurrence</h2>
  	</div>
  </div>

<?php echo $_smarty_tpl->getSubTemplate ('curricularUnit/changeUnitOccurrence.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

  
	  	<div class="form-group">
	  		<div class="col-md-4 col-md-offset-4">
	  			<button type="submit" name="unitSubmit" class="btn btn-primary">Create New Curricular Unit Occurrence</button>
	  		</div>
	  	</div>
	  </div>
  </form>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
