<?php /* Smarty version Smarty-3.1.15, created on 2016-06-06 05:58:14
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\course\courseList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:296845754f4d662b0f3-17192345%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8df4ebd54548778cb7813cb619e18af918137a8' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\course\\courseList.tpl',
      1 => 1465182326,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '296845754f4d662b0f3-17192345',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5754f4d662efa5_99463165',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5754f4d662efa5_99463165')) {function content_5754f4d662efa5_99463165($_smarty_tpl) {?><table class="table table-striped">
  <thead>
    <tr class="head">
      <th>Courses</th>
      <th>Director</th>
      <th>Creation Date</th>
      <th>Duration (years)</th>
      <th>Academic Degree </th>
    </tr>
  </thead>
  <tbody class="courseListBody" id="course_list">

  </tbody>
</table><?php }} ?>
