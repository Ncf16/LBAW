<?php /* Smarty version Smarty-3.1.15, created on 2016-06-06 05:58:14
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\common\search.tpl" */ ?>
<?php /*%%SmartyHeaderCode:250315754f4d661cb22-91023680%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6925fc7975126b495d852367b7b5608e2cef6c12' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\common\\search.tpl',
      1 => 1465182326,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '250315754f4d661cb22-91023680',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5754f4d6620c13_81493276',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5754f4d6620c13_81493276')) {function content_5754f4d6620c13_81493276($_smarty_tpl) {?><div class="container">
  <div class="row">
      <div id="custom-search-input">
        <div class="input-group col-md-12">
            <input type="text" class="search-query form-control" placeholder="Search"/>
            <span class="input-group-btn">
              <button id="search_button" class="btn btn-danger" type="button">
                <span class=" glyphicon glyphicon-search"></span>
              </button>
            </span>
        </div>
      </div>
  </div>
</div><?php }} ?>
