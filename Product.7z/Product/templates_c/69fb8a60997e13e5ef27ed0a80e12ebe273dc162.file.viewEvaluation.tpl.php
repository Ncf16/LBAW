<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 05:43:31
         compiled from "C:\Users\Filipe\Desktop\FEUP\XAMPP\htdocs\LBAW\Product\templates\evaluation\viewEvaluation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:22853575631563c0134-24675471%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '69fb8a60997e13e5ef27ed0a80e12ebe273dc162' => 
    array (
      0 => 'C:\\Users\\Filipe\\Desktop\\FEUP\\XAMPP\\htdocs\\LBAW\\Product\\templates\\evaluation\\viewEvaluation.tpl',
      1 => 1465271010,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22853575631563c0134-24675471',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57563156400b17_80861028',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'permission' => 0,
    'evaluation' => 0,
    'accountType' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57563156400b17_80861028')) {function content_57563156400b17_80861028($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<link href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/listTables.css" rel="stylesheet">
<div id="evaluationPage" class="container">
  <div class="row">
    <div class="col-sm-10">
      <h1 class="page-header hidden-sm hidden-xs">Evaluation</h1>
     <?php if ($_smarty_tpl->tpl_vars['permission']->value==true) {?>
         <input hidden id="deleteID" value="<?php echo $_GET['evaluationID'];?>
"/> 
        <a href="#" id="deleteEval" class="btn btn-primary btn-primary">Delete Evaluation </a>
     <?php }?>
    </div>
  </div>

      <hr>
  <div class="row">
    <div class="col-md-10 col-md-offset-1 ">
      <div>
        <h2>Information</h2>
      </div>
        <br>
      <table class="table table-responsive classInfo">
            <tr>
                <td class="border">
                    Curricular Unit: <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/CurricularUnit/viewUnitOccurrence.php?uc=<?php echo $_smarty_tpl->tpl_vars['evaluation']->value['cuoccurrenceid'];?>
"><?php echo $_smarty_tpl->tpl_vars['evaluation']->value['name'];?>
</a>
                </td>
                <td>School Year: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['calendaryear'];?>
</td>
            </tr>
            <tr>
                <td class="border">Date: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['day'];?>
</td>
                <td>Time: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['time'];?>
</td>
            </tr>
            <tr>
                <td class="border">Evaluation Type: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['evaluationtype'];?>
</td>
                <td>Weight: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['weight'];?>
</td>
            </tr>
            <tr>
                <?php if ($_smarty_tpl->tpl_vars['evaluation']->value['evaluationtype']=='GroupWork') {?>
                <td class="border">Minimum Elements: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['minelements'];?>
</td>
                <td>Maximum Elements: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['maxelements'];?>
</td>
                <?php } elseif ($_smarty_tpl->tpl_vars['evaluation']->value['evaluationtype']=='Exam'||$_smarty_tpl->tpl_vars['evaluation']->value['evaluationtype']=='Test') {?>
                <td colspan="2">Duration: <?php echo $_smarty_tpl->tpl_vars['evaluation']->value['duration'];?>
</td>
                <?php }?>
            </tr>
       </table>
    </div>
</div>
  <p>
  <hr>
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <h3>Grades</h3>
      <br>
      <table id="mytable" class="table table-bordred table-striped">
         <thead>
            <th class="col-md-2" colspan="2">Grade</th>
            <?php if ($_smarty_tpl->tpl_vars['accountType']->value!='Student') {?>
            <th class="col-md-9">Student Name</th>
            <th class="col-md-1">Delete</th>
            <?php } else { ?>
            <th class="col-md-10">Student Name</th>
            <?php }?>
         </thead>
         <tbody id="grades">
         </tbody>
      </table>

      <div class="clearfix"></div>
      <ul class="pagination pull-right">
      </ul>
   </div>
 </div>
  </p>
</div>

<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/Pagination.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/viewEvaluation.js"></script>
<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
