<?php
  include_once($BASE_DIR . '/config/init.php');
//Empty for now
?>
