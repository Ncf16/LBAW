<?php
  header('Location: pages/tweets/list_all.php');
?>
